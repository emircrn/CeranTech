-- PostgreSQL script to create and populate the products table
-- Generated from CSV data

-- Drop the table if it exists (optional, for clean re-runs)
DROP TABLE IF EXISTS products;

-- Create the products table
CREATE TABLE products (
    id INTEGER PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    image_url VARCHAR(500),
    category VARCHAR(100)
);

-- Insert product records
INSERT INTO products (id, name, description, price, image_url, category) VALUES
(1, 'iPhone 14', 'Vital safety features, massive camera upgrade.', 699.00, '/img/14.jpg', 'Phone'),
(2, 'iPhone 14 Pro', 'Dynamic Island, Always-On display.', 899.00, '/img/14pro.jpg', 'Phone'),
(3, 'iPhone 14 Pro Max', 'A16 Bionic, 48MP Main camera.', 999.00, '/img/14promax.jpg', 'Phone'),
(4, 'iPhone 15', 'Color-infused glass, USB-C connector.', 799.00, '/img/15.jpg', 'Phone'),
(5, 'iPhone 15 Pro', 'Titanium design, A17 Pro chip.', 999.00, '/img/15pro.jpg', 'Phone'),
(6, 'iPhone 15 Pro Max', '5x Telephoto camera, lightest Pro model.', 1199.00, '/img/15promax.jpg', 'Phone'),
(7, 'iPhone 16', 'Capture Button, Spatial Video support.', 899.00, '/img/16.jpg', 'Phone'),
(8, 'iPhone 16 Pro', 'Larger 6.3 inch display, A18 Pro Chip.', 1099.00, '/img/16pro.jpg', 'Phone'),
(9, 'iPhone 16 Pro Max', 'Largest iPhone display ever (6.9 inch).', 1299.00, '/img/16promax.jpg', 'Phone'),
(10, 'iPhone 17', 'Revolutionary holographic display, A19 Bionic chip.', 999.00, '/img/17.jpg', 'Phone'),
(11, 'iPhone 17 Pro', 'Under-display Face ID, pro-grade camera system.', 1199.00, '/img/17pro.jpg', 'Phone'),
(12, 'iPhone 17 Pro Max', 'All-glass unibody design, the most powerful iPhone ever.', 1499.00, '/img/17promax.jpg', 'Phone'),
(13, 'MacBook Air M2', 'Impossibly thin. Incredibly fast.', 999.00, '/img/m2.jpg', 'Laptop'),
(14, 'MacBook Air M3', 'Lean. Mean. M3 machine.', 1099.00, '/img/m3.jpg', 'Laptop'),
(15, 'MacBook Pro 14"', 'Mind-blowing. Head-turning. M3 Pro.', 1599.00, '/img/pro14.jpg', 'Laptop'),
(16, 'MacBook Pro 16"', 'The most powerful MacBook ever.', 2499.00, '/img/pro16.jpg', 'Laptop'),
(17, 'AirPods 3rd Gen', 'All-new design with Spatial Audio.', 169.00, '/img/3.jpg', 'Audio'),
(18, 'AirPods Pro 2', 'Up to 2x more Active Noise Cancellation.', 249.00, '/img/pro2.jpg', 'Audio'),
(19, 'AirPods Max', 'High-fidelity audio. Effortless magic.', 549.00, '/img/podmax.jpg', 'Audio');

-- Verify the data was inserted
SELECT COUNT(*) as total_products FROM products;
