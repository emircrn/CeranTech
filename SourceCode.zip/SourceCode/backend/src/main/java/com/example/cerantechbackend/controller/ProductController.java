package com.example.cerantechbackend.controller;

import com.example.cerantechbackend.model.Product;
import com.example.cerantechbackend.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:3000") // React access
public class ProductController {

    @Autowired
    private ProductRepository productRepository;

    // Take all product
    @GetMapping
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // Maybe Admin Panel
    @PostMapping
    public Product createProduct(@RequestBody Product product) {
        return productRepository.save(product);
    }
}