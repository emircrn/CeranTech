package com.example.cerantechbackend.controller;

import com.example.cerantechbackend.model.User;
import com.example.cerantechbackend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    // (Register)
    @PostMapping("/register")
    public Map<String, String> register(@RequestBody User user) {
        Map<String, String> response = new HashMap<>();

        if (userRepository.findByUsername(user.getUsername()) != null) {
            response.put("status", "error");
            response.put("message", "Username already exists!");
            return response;
        }

        userRepository.save(user);
        response.put("status", "success");
        response.put("message", "Registration successful! Please login.");
        return response;
    }

    // (Login)
    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody User loginData) {
        Map<String, Object> response = new HashMap<>();
        User user = userRepository.findByUsername(loginData.getUsername());

        if (user != null && user.getPassword().equals(loginData.getPassword())) {
            response.put("status", "success");
            response.put("message", "Login successful!");
            response.put("fullName", user.getFullName()); // Write name screen
        } else {
            response.put("status", "error");
            response.put("message", "Invalid username or password");
        }
        return response;
    }
}