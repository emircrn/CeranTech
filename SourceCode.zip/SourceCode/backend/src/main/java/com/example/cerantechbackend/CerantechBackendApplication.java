package com.example.cerantechbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CerantechBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(CerantechBackendApplication.class, args);
    }

}
