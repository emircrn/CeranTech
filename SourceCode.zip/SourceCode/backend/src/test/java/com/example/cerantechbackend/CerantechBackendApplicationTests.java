package com.example.cerantechbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CerantechBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
