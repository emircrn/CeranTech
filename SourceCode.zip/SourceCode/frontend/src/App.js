import React, { useState, useEffect } from 'react';
import {
    AppBar, Toolbar, Typography, Button, Grid, Card, CardContent, CardMedia,
    Container, TextField, Dialog, DialogContent, DialogTitle, Box, Chip,
    Badge, Snackbar, Alert, Drawer, List, Avatar, IconButton,
    Rating, Paper, Tabs, Tab, InputAdornment
} from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import VerifiedUserIcon from '@mui/icons-material/VerifiedUser';
import DeleteIcon from '@mui/icons-material/Delete';
import CloseIcon from '@mui/icons-material/Close';
import LogoutIcon from '@mui/icons-material/Logout';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';
import LaptopMacIcon from '@mui/icons-material/LaptopMac';
import HeadphonesIcon from '@mui/icons-material/Headphones';
import AppsIcon from '@mui/icons-material/Apps';
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import SearchIcon from '@mui/icons-material/Search';
import axios from 'axios';

// --- color ---
const themeColor = '#0F4C75';
const bgColor = '#F8F9FA';
const cardBg = '#FFFFFF';

// --- product card ---
const ProductCard = ({ product, onAddToCart }) => {
    const [selectedStorage, setSelectedStorage] = useState('256GB');
    const isPhone = product.category === 'Phone';

    const currentPrice = (selectedStorage === '1TB' && isPhone)
        ? product.price + 200
        : product.price;

    const handleStorageChange = (storage) => {
        setSelectedStorage(storage);
    };

    const handleAddClick = () => {
        onAddToCart({
            ...product,
            price: currentPrice,
            name: isPhone ? `${product.name} (${selectedStorage})` : product.name
        });
    };

    return (
        <Card sx={{
            width: '100%', display: 'flex', flexDirection: 'column',
            borderRadius: '24px', border: 'none',
            boxShadow: '0 12px 24px rgba(0,0,0,0.05)',
            position: 'relative', transition: 'all 0.3s ease', bgcolor: cardBg,
            overflow: 'visible',
            ':hover': { transform: 'translateY(-8px)', boxShadow: '0 20px 40px rgba(0,0,0,0.1)' }
        }}>
            {product.name.includes('17') && (
                <Chip
                    label="New Arrival"
                    size="small"
                    sx={{
                        position: 'absolute', top: -10, right: 20, zIndex: 20,
                        background: 'linear-gradient(45deg, #ff5f6d, #ffc371)',
                        color: 'white', fontWeight: 800, fontSize: '0.7rem', height: 28,
                        boxShadow: '0 4px 10px rgba(255, 95, 109, 0.4)'
                    }}
                />
            )}

            <Box sx={{
                height: 260, width: '100%',
                display: 'flex', justifyContent: 'center', alignItems: 'center',
                p: 4, bgcolor: cardBg, borderRadius: '24px 24px 0 0'
            }}>
                <CardMedia
                    component="img"
                    image={product.imageUrl}
                    alt={product.name}
                    sx={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
                    onError={(e) => { e.target.src = 'https://via.placeholder.com/200?text=CeranTech'; }}
                />
            </Box>

            <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', p: 3, pt: 1 }}>
                <Typography variant="caption" sx={{ color: '#999', fontWeight: 700, letterSpacing: '1px', mb: 1 }}>
                    {product.category.toUpperCase()}
                </Typography>

                <Typography gutterBottom variant="h5" component="div" sx={{ fontWeight: 800, fontSize: '1.25rem', lineHeight: 1.2, color: '#1a1a1a' }}>
                    {product.name}
                </Typography>

                <Rating value={5} readOnly size="small" sx={{ color: '#FFD700', mb: 2 }} />

                <Typography variant="body2" sx={{ color: '#666', mb: 2, minHeight: '40px', overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', lineHeight: 1.5 }}>
                    {product.description}
                </Typography>

                {isPhone && (
                    <Box sx={{ display: 'flex', gap: 1, mb: 3, p: 0.5, bgcolor: '#f1f3f5', borderRadius: 50, width: 'fit-content' }}>
                        {['256GB', '1TB'].map((storage) => (
                            <Box
                                key={storage}
                                onClick={() => handleStorageChange(storage)}
                                sx={{
                                    px: 2, py: 0.5, borderRadius: 50, cursor: 'pointer',
                                    fontWeight: 700, fontSize: '0.75rem', transition: 'all 0.2s',
                                    bgcolor: selectedStorage === storage ? '#fff' : 'transparent',
                                    color: selectedStorage === storage ? '#000' : '#888',
                                    boxShadow: selectedStorage === storage ? '0 2px 5px rgba(0,0,0,0.1)' : 'none'
                                }}
                            >
                                {storage}
                            </Box>
                        ))}
                    </Box>
                )}

                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 'auto' }}>
                    <Typography key={currentPrice} variant="h6" sx={{ fontWeight: 900, color: themeColor, fontSize: '1.4rem', animation: 'fadeIn 0.3s' }}>
                        ${currentPrice.toFixed(2)}
                    </Typography>

                    <Button
                        variant="contained"
                        disableElevation
                        onClick={handleAddClick}
                        sx={{
                            bgcolor: themeColor,
                            color: 'white',
                            textTransform: 'none',
                            fontWeight: 700,
                            borderRadius: 50,
                            px: 3, py: 1,
                            '&:hover': { bgcolor: '#0a3d5e' }
                        }}
                    >
                        Add to Cart
                    </Button>
                </Box>
            </CardContent>
        </Card>
    );
};

// --- main app---
function App() {
    const [products, setProducts] = useState([]);
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [searchTerm, setSearchTerm] = useState("");

    const [openAuthModal, setOpenAuthModal] = useState(false);
    const [isRegisterMode, setIsRegisterMode] = useState(false);
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [fullName, setFullName] = useState("");
    const [currentUser, setCurrentUser] = useState(null);

    const [cart, setCart] = useState([]);
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [isCheckingOut, setIsCheckingOut] = useState(false);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });

    useEffect(() => {
        const storedUser = localStorage.getItem('user');
        if (storedUser) {
            setCurrentUser(storedUser);
        }

        axios.get('http://localhost:8080/api/products')
            .then(response => {
                setProducts(response.data);
                setFilteredProducts(response.data);
            })
            .catch(error => console.error("Error fetching products:", error));
    }, []);

    useEffect(() => {
        let result = products;

        if (selectedCategory !== 'All') {
            result = result.filter(product => product.category === selectedCategory);
        }

        if (searchTerm) {
            result = result.filter(product =>
                product.name.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        setFilteredProducts(result);
    }, [searchTerm, selectedCategory, products]);

    const handleCategoryChange = (event, newValue) => {
        setSelectedCategory(newValue);
    };

    const handleSearchChange = (event) => {
        setSearchTerm(event.target.value);
    };

    const addToCart = (productWithDetails) => {
        setCart([...cart, productWithDetails]);
        setSnackbar({ open: true, message: `${productWithDetails.name} added to cart!`, severity: 'success' });
    };

    const removeFromCart = (indexToRemove) => {
        setCart(cart.filter((_, index) => index !== indexToRemove));
    };

    const calculateTotal = () => {
        return cart.reduce((total, item) => total + item.price, 0).toFixed(2);
    };

    const handleCheckout = () => {
        if (!currentUser) {
            setSnackbar({ open: true, message: 'Please log in to place an order!', severity: 'warning' });
            setOpenAuthModal(true);
            return;
        }
        if (cart.length === 0) {
            setSnackbar({ open: true, message: 'Your cart is empty!', severity: 'warning' });
            return;
        }
        setIsCheckingOut(true);
        setTimeout(() => {
            setIsCheckingOut(false);
            setCart([]);
            setIsCartOpen(false);
            setSnackbar({ open: true, message: 'Order placed successfully! Thank you.', severity: 'success' });
        }, 2000);
    };

    // --- login register security ---
    const handleAuth = () => {
        // --- 1. login check ---
        if (isRegisterMode) {
            // username condition
            if (username.trim().length < 4 || !/^[a-zA-Z0-9]+$/.test(username)) {
                setSnackbar({ open: true, message: 'Username must be 4+ chars (No spaces/symbols).', severity: 'warning' });
                return;
            }
            // password: Min 6
            if (password.length < 6) {
                setSnackbar({ open: true, message: 'Password must be at least 6 characters.', severity: 'warning' });
                return;
            }
            // name: Min 3 , must include letter
            if (fullName.trim().length < 3 || !/[a-zA-Z]/.test(fullName)) {
                setSnackbar({ open: true, message: 'Please enter a valid full name.', severity: 'warning' });
                return;
            }
        }
        // --- finish validation ---

        const endpoint = isRegisterMode ? 'register' : 'login';
        const payload = isRegisterMode ? { username, password, fullName } : { username, password };

        axios.post(`http://localhost:8080/api/auth/${endpoint}`, payload)
            .then(response => {
                if (response.data.status === 'success') {
                    if (!isRegisterMode) {
                        const user = response.data.fullName || username;
                        localStorage.setItem('user', user);
                        setCurrentUser(user);
                        setOpenAuthModal(false);
                        setSnackbar({ open: true, message: `Welcome back, ${user}!`, severity: 'success' });
                    } else {
                        setSnackbar({ open: true, message: 'Registration Successful! Please Login.', severity: 'success' });
                        setIsRegisterMode(false);
                    }
                } else {
                    setSnackbar({ open: true, message: response.data.message || 'Error occurred', severity: 'error' });
                }
            })
            .catch(error => {
                setSnackbar({ open: true, message: 'Connection error!', severity: 'error' });
            });
    };

    const handleLogout = () => {
        localStorage.removeItem('user');
        setCurrentUser(null);
        setCart([]);
        setSnackbar({ open: true, message: 'Logged out successfully.', severity: 'info' });
    };

    return (
        <Box sx={{ flexGrow: 1, bgcolor: bgColor, minHeight: '100vh', display: 'flex', flexDirection: 'column', fontFamily: '"Inter", "Roboto", sans-serif' }}>

            {/* --- NAVBAR --- */}
            <AppBar position="sticky" elevation={0} sx={{ bgcolor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)' }}>
                <Container maxWidth="xl">
                    <Toolbar disableGutters sx={{ py: 1.5, gap: 2 }}>
                        {/* LOGO */}
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            <VerifiedUserIcon sx={{ mr: 1.5, color: themeColor, fontSize: 40 }} />
                            <Typography
                                variant="h5"
                                noWrap
                                component="a"
                                href="/"
                                sx={{
                                    mr: 2,
                                    display: { xs: 'none', md: 'flex' },
                                    fontFamily: 'monospace',
                                    fontWeight: 900,
                                    letterSpacing: '.3rem',
                                    background: `linear-gradient(45deg, ${themeColor}, #00d2ff)`,
                                    backgroundClip: "text",
                                    textFillColor: "transparent",
                                    WebkitBackgroundClip: "text",
                                    WebkitTextFillColor: "transparent",
                                    textDecoration: 'none',
                                    fontSize: '2.2rem'
                                }}
                            >
                                CERANTECH
                            </Typography>
                        </Box>

                        {/* -- search  -- */}
                        <TextField
                            size="small"
                            placeholder="Search products..."
                            value={searchTerm}
                            onChange={handleSearchChange}
                            sx={{
                                flexGrow: 1,
                                maxWidth: 600,
                                bgcolor: '#f1f3f5',
                                borderRadius: 50,
                                '& .MuiOutlinedInput-root': {
                                    borderRadius: 50,
                                    '& fieldset': { border: 'none' },
                                }
                            }}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <SearchIcon sx={{ color: themeColor }} />
                                    </InputAdornment>
                                ),
                            }}
                        />

                        {/* BUTTONS */}
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                            <IconButton onClick={() => setIsCartOpen(true)} sx={{ color: themeColor, bgcolor: '#f0f4f8' }}>
                                <Badge badgeContent={cart.length} color="error">
                                    <ShoppingCartIcon />
                                </Badge>
                            </IconButton>

                            {currentUser ? (
                                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, bgcolor: '#f0f4f8', px: 2, py: 0.5, borderRadius: 50 }}>
                                    <Typography sx={{ color: themeColor, fontWeight: 700, fontSize: '0.9rem' }}>{currentUser}</Typography>
                                    <IconButton size="small" onClick={handleLogout} sx={{ color: themeColor }}><LogoutIcon fontSize="small" /></IconButton>
                                </Box>
                            ) : (
                                <Button variant="contained" onClick={() => setOpenAuthModal(true)} sx={{ borderRadius: 50, bgcolor: themeColor, fontWeight: 'bold', textTransform: 'none', px: 3, boxShadow: 'none' }}>
                                    Sign In
                                </Button>
                            )}
                        </Box>
                    </Toolbar>
                </Container>
            </AppBar>

            {/* --- HERO SECTION --- */}
            <Box sx={{
                position: 'relative', overflow: 'hidden', py: { xs: 10, md: 16 }, textAlign: 'center',
                background: `linear-gradient(135deg, ${themeColor} 0%, #051926 100%)`, color: 'white',
            }}>
                <Container maxWidth="md" sx={{ position: 'relative', zIndex: 2 }}>
                    <Typography variant="h2" component="h1" gutterBottom sx={{
                        fontWeight: 900, letterSpacing: '-1.5px', mb: 2,
                        background: 'linear-gradient(to right, #ffffff, #a5b4fc)',
                        backgroundClip: 'text', textFillColor: "transparent", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
                        fontSize: { xs: '2.5rem', md: '4rem' }
                    }}>
                        Performance. Redefined.
                    </Typography>
                    <Typography variant="h6" sx={{ opacity: 0.8, fontWeight: 400, maxWidth: '700px', mx: 'auto', fontSize: { xs: '1rem', md: '1.25rem' }, lineHeight: 1.6 }}>
                        Experience the pinnacle of engineering. From the titanium finish of the iPhone 15 to the raw power of the M3 chip.
                    </Typography>
                    <Button
                        variant="outlined" size="large"
                        sx={{
                            mt: 4, color: 'white', borderColor: 'white', borderRadius: 50, px: 5, py: 1.5, textTransform: 'none', fontSize: '1.1rem', borderWidth: 2,
                            '&:hover': { borderColor: '#00d2ff', color: '#00d2ff', background: 'rgba(0, 210, 255, 0.05)', borderWidth: 2 }
                        }}
                        onClick={() => { window.scrollTo({ top: 600, behavior: 'smooth' }); }}
                    >
                        Explore Collection
                    </Button>
                </Container>
            </Box>

            {/* category */}
            <Container maxWidth="lg" sx={{ mt: -5, mb: 6, position: 'relative', zIndex: 3 }}>
                <Paper elevation={0} sx={{ borderRadius: 50, bgcolor: 'rgba(255,255,255,0.9)', backdropFilter: 'blur(10px)', p: 1, display: 'flex', justifyContent: 'center', boxShadow: '0 10px 30px rgba(0,0,0,0.05)' }}>
                    <Tabs
                        value={selectedCategory} onChange={handleCategoryChange}
                        TabIndicatorProps={{ style: { display: 'none' } }} variant="scrollable" scrollButtons="auto"
                        sx={{ '& .MuiTabs-flexContainer': { gap: 2 } }}
                    >
                        {[
                            { label: 'All', icon: <AppsIcon />, val: 'All' },
                            { label: 'Phones', icon: <PhoneIphoneIcon />, val: 'Phone' },
                            { label: 'Laptops', icon: <LaptopMacIcon />, val: 'Laptop' },
                            { label: 'Audio', icon: <HeadphonesIcon />, val: 'Audio' }
                        ].map((tab) => (
                            <Tab key={tab.val} label={tab.label} value={tab.val} icon={tab.icon} iconPosition="start"
                                 sx={{
                                     fontWeight: 700, minHeight: 50, borderRadius: 50, px: 4, textTransform: 'none',
                                     color: selectedCategory === tab.val ? 'white !important' : themeColor,
                                     bgcolor: selectedCategory === tab.val ? themeColor : 'transparent',
                                     transition: 'all 0.3s ease'
                                 }}
                            />
                        ))}
                    </Tabs>
                </Paper>
            </Container>

            {/* product list*/}
            <Container maxWidth="xl" sx={{ mb: 10 }}>
                {filteredProducts.length === 0 && (
                    <Box sx={{ textAlign: 'center', py: 5 }}>
                        <Typography variant="h6" color="text.secondary">No products found for "{searchTerm}".</Typography>
                    </Box>
                )}

                <Grid container spacing={4} justifyContent="center" alignItems="stretch">
                    {filteredProducts.map((product) => (
                        <Grid item key={product.id} xs={12} sm={6} md={4} lg={3} sx={{ display: 'flex' }}>
                            <ProductCard product={product} onAddToCart={addToCart} />
                        </Grid>
                    ))}
                </Grid>
            </Container>

            {/* --- FOOTER --- */}
            <Box component="footer" sx={{ bgcolor: themeColor, color: 'white', py: 8, mt: 'auto', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
                <Container maxWidth="lg">
                    <Grid container spacing={5} justifyContent="space-between">
                        <Grid item xs={12} md={5}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                                <VerifiedUserIcon sx={{ color: '#00d2ff', fontSize: 30 }} />
                                <Typography variant="h6" fontWeight="900" sx={{ letterSpacing: '1px' }}>
                                    CERANTECH
                                </Typography>
                            </Box>
                            <Typography variant="body2" sx={{ opacity: 0.7, lineHeight: 1.8 }}>
                                Your premium destination for high-end technology.
                                We bring the future to your doorstep with guaranteed quality and performance.
                            </Typography>
                        </Grid>
                        <Grid item xs={12} md={5}>
                            <Typography variant="h6" fontWeight="bold" gutterBottom sx={{ color: '#00d2ff' }}>
                                Follow Us
                            </Typography>
                            <Typography variant="body2" sx={{ opacity: 0.7, mb: 2 }}>
                                Stay updated with the latest tech news and exclusive offers.
                            </Typography>
                            <Box sx={{ display: 'flex', gap: 2 }}>
                                <InstagramIcon sx={{ cursor: 'pointer', transition: '0.2s', '&:hover': { color: '#E1306C', transform: 'scale(1.2)' } }} />
                                <TwitterIcon sx={{ cursor: 'pointer', transition: '0.2s', '&:hover': { color: '#1DA1F2', transform: 'scale(1.2)' } }} />
                                <FacebookIcon sx={{ cursor: 'pointer', transition: '0.2s', '&:hover': { color: '#4267B2', transform: 'scale(1.2)' } }} />
                                <LinkedInIcon sx={{ cursor: 'pointer', transition: '0.2s', '&:hover': { color: '#0077b5', transform: 'scale(1.2)' } }} />
                            </Box>
                        </Grid>
                    </Grid>
                    <Box sx={{ mt: 6, pt: 3, borderTop: '1px solid rgba(255,255,255,0.1)', textAlign: 'center' }}>
                        <Typography variant="caption" sx={{ opacity: 0.5 }}>
                            © {new Date().getFullYear()} CeranTech Inc. All rights reserved.
                        </Typography>
                    </Box>
                </Container>
            </Box>

            {/* CART DRAWER */}
            <Drawer anchor="right" open={isCartOpen} onClose={() => setIsCartOpen(false)} PaperProps={{ sx: { width: { xs: '100%', sm: 400 }, p: 3, bgcolor: bgColor } }}>
                <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                        <Typography variant="h5" fontWeight="900" color={themeColor}>Your Cart</Typography>
                        <IconButton onClick={() => setIsCartOpen(false)} sx={{ bgcolor: 'white' }}><CloseIcon /></IconButton>
                    </Box>
                    <List sx={{ flexGrow: 1, overflow: 'auto' }}>
                        {cart.map((item, index) => (
                            <Box key={index} sx={{ mb: 2, p: 2, bgcolor: 'white', borderRadius: 4, display: 'flex', alignItems: 'center', boxShadow: '0 5px 15px rgba(0,0,0,0.03)' }}>
                                <Avatar src={item.imageUrl} variant="rounded" sx={{ width: 70, height: 70, mr: 2, objectFit: 'contain', bgcolor: '#f0f4f8', p: 1, borderRadius: 3 }} />
                                <Box sx={{ flexGrow: 1 }}>
                                    <Typography variant="subtitle1" fontWeight="800">{item.name}</Typography>
                                    <Typography variant="body2" fontWeight="700" color={themeColor}>${item.price.toFixed(2)}</Typography>
                                </Box>
                                <IconButton onClick={() => removeFromCart(index)} size="small" sx={{ color: '#ff4757', bgcolor: '#fff0f1' }}><DeleteIcon /></IconButton>
                            </Box>
                        ))}
                    </List>
                    <Button
                        variant="contained" fullWidth size="large"
                        disabled={isCheckingOut || cart.length === 0}
                        onClick={handleCheckout}
                        sx={{ mt: 3, bgcolor: isCheckingOut ? '#ccc' : themeColor, fontWeight: 800, borderRadius: 50, py: 2, boxShadow: 'none' }}
                    >
                        {isCheckingOut ? "Processing..." : `Checkout ($${calculateTotal()})`}
                    </Button>
                </Box>
            </Drawer>

            <Dialog open={openAuthModal} onClose={() => setOpenAuthModal(false)} maxWidth="xs" fullWidth PaperProps={{ sx: { borderRadius: 4, p: 2 } }}>
                <DialogTitle align="center" sx={{ fontWeight: 900, color: themeColor, fontSize: '1.5rem' }}>{isRegisterMode ? "Create Account" : "Welcome Back"}</DialogTitle>
                <DialogContent>
                    <Box sx={{ mt: 3, display: 'flex', flexDirection: 'column', gap: 2.5 }}>
                        {isRegisterMode && <TextField fullWidth label="Full Name" variant="outlined" InputProps={{ style: { borderRadius: 16 } }} value={fullName} onChange={(e) => setFullName(e.target.value)} />}
                        <TextField fullWidth label="Username" variant="outlined" InputProps={{ style: { borderRadius: 16 } }} value={username} onChange={(e) => setUsername(e.target.value)} />
                        <TextField fullWidth label="Password" type="password" variant="outlined" InputProps={{ style: { borderRadius: 16 } }} value={password} onChange={(e) => setPassword(e.target.value)} />
                        <Button fullWidth variant="contained" onClick={handleAuth} sx={{ mt: 1, bgcolor: themeColor, borderRadius: 50, py: 1.5, fontWeight: 700, boxShadow: 'none' }}>{isRegisterMode ? "Sign Up" : "Log In"}</Button>
                        <Button fullWidth onClick={() => setIsRegisterMode(!isRegisterMode)} sx={{ textTransform: 'none', color: '#666' }}>{isRegisterMode ? "Login" : "Create account"}</Button>
                    </Box>
                </DialogContent>
            </Dialog>

            <Snackbar open={snackbar.open} autoHideDuration={3000} onClose={() => setSnackbar({ ...snackbar, open: false })}>
                <Alert severity={snackbar.severity} sx={{ width: '100%', borderRadius: 3 }}>{snackbar.message}</Alert>
            </Snackbar>
        </Box>
    );
}

export default App;